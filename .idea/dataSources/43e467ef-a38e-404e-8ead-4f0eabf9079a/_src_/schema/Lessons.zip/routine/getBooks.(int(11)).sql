CREATE PROCEDURE getBooks(IN bookId INT)
  BEGIN
  select * from Books where id = bookId;
END;
