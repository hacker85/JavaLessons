CREATE PROCEDURE `getBooks`(IN `bookId` INT(11))
  BEGIN
  select * from Books where id = bookId;
END