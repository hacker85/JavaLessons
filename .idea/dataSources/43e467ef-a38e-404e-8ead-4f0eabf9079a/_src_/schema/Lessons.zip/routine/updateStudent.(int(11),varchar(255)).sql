CREATE PROCEDURE updateStudent(IN studentId INT, IN newName VARCHAR(255))
  BEGIN 
    update STUDENT set name = newName where id = studentId;
  END;
