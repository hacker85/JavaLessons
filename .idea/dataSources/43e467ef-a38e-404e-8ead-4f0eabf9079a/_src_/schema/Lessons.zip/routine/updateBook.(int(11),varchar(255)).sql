CREATE PROCEDURE updateBook(IN bookId INT, IN newTitle VARCHAR(255))
  BEGIN
    UPDATE BOOK SET TITLE = newTitle WHERE id = bookId;
  END;
