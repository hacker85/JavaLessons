CREATE PROCEDURE BooksCount(OUT cnt INT)
  BEGIN
  select count(*) into cnt from Books;
END;
