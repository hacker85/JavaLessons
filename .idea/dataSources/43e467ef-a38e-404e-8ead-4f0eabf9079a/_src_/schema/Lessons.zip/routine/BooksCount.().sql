CREATE PROCEDURE `BooksCount`(OUT `cnt` INT(11))
  BEGIN
  select count(*) into cnt from Books;
END